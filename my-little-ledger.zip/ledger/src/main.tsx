import React from 'react'
import { createRoot } from 'react-dom/client'
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom'
import { AuthProvider, useAuth } from './lib/auth'
import AuthPage from './pages/AuthPage'
import Home from './pages/Home'
import './styles.css'
function Guard({ children }: { children: JSX.Element }) {
  const { session, ready } = useAuth()
  if (!ready) return null
  return session ? children : <Navigate to="/login" replace />
}
createRoot(document.getElementById('root')!).render(
  <React.StrictMode><AuthProvider><BrowserRouter><Routes>
    <Route path="/login" element={<AuthPage mode="login" />} />
    <Route path="/signup" element={<AuthPage mode="signup" />} />
    <Route path="/" element={<Guard><Home /></Guard>} />
    <Route path="*" element={<Navigate to="/" />} />
  </Routes></BrowserRouter></AuthProvider></React.StrictMode>)

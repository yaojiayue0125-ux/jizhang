import { UtensilsCrossed, CupSoda, Cake, Shirt, Sparkles, Car, Star, Brush } from 'lucide-react'
export type CategoryId = 'food'|'drinks'|'treats'|'daily_goods'|'fashion'|'beauty'|'transport'|'entertainment'
// TODO: swap daily_goods -> custom hanger SVG and fashion -> custom coat SVG (Lucide has no exact match)
export const CATEGORIES: { id: CategoryId; zh: string; en: string; color: string; Icon: any }[] = [
  { id:'food', zh:'餐食', en:'FOOD', color:'#F6DCE4', Icon:UtensilsCrossed },
  { id:'drinks', zh:'饮品', en:'DRINKS', color:'#DCEFE4', Icon:CupSoda },
  { id:'treats', zh:'改善饮食', en:'TREATS', color:'#F7E7C5', Icon:Cake },
  { id:'daily_goods', zh:'日用品', en:'DAILY GOODS', color:'#E4DDF5', Icon:Brush },
  { id:'fashion', zh:'服装', en:'FASHION', color:'#DDE8F8', Icon:Shirt },
  { id:'beauty', zh:'化妆品', en:'BEAUTY', color:'#F5DDEB', Icon:Sparkles },
  { id:'transport', zh:'出行', en:'TRANSPORT', color:'#D8EEEE', Icon:Car },
  { id:'entertainment', zh:'娱乐', en:'ENTERTAINMENT', color:'#EEDDF5', Icon:Star },
]
export const PAYMENTS = [['wechat','微信支付'],['alipay','支付宝'],['card','银行卡'],['cash','现金'],['other','其他']] as const
export const yuan = (n: number) => '¥' + n.toFixed(2)

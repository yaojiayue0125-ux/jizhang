import { useState, FormEvent } from 'react'
import { supabase } from '../lib/supabase'
import { CATEGORIES, PAYMENTS } from '../lib/categories'
export type Expense = { id: string; title: string; amount: number; category: string; expense_date: string; payment_method: string | null; note: string | null }
export default function ExpenseForm({ initial, onClose, onSaved }: { initial?: Expense; onClose: () => void; onSaved: () => void }) {
  const [f, setF] = useState({
    title: initial?.title ?? '', amount: initial ? String(initial.amount) : '', category: initial?.category ?? 'food',
    expense_date: initial?.expense_date ?? new Date().toLocaleDateString('sv'), payment_method: initial?.payment_method ?? '', note: initial?.note ?? '' })
  const [err, setErr] = useState(''); const [busy, setBusy] = useState(false)
  async function submit(e: FormEvent) {
    e.preventDefault(); if (busy) return
    if (!/^\d+(\.\d{1,2})?$/.test(f.amount) || Number(f.amount) <= 0) return setErr('金额须大于 0，最多两位小数。')
    setBusy(true); setErr('')
    const row = { title: f.title.trim(), amount: f.amount, category: f.category, expense_date: f.expense_date,
      payment_method: f.payment_method || null, note: f.note.trim() || null }
    const { error } = initial ? await supabase.from('expenses').update(row).eq('id', initial.id) : await supabase.from('expenses').insert(row)
    setBusy(false)
    if (error) return setErr('保存失败：' + error.message)
    onSaved()
  }
  const set = (k: string) => (e: any) => setF({ ...f, [k]: e.target.value })
  return (
    <div className="modal" role="dialog" aria-modal="true"><form className="bill sheet" onSubmit={submit}>
      <h2>{initial ? 'Edit expense' : 'New expense'}</h2>
      <label>消费名称<input required maxLength={100} value={f.title} onChange={set('title')} /></label>
      <label>金额 ¥<input required inputMode="decimal" value={f.amount} onChange={set('amount')} placeholder="18.00" /></label>
      <label>分类<select value={f.category} onChange={set('category')}>{CATEGORIES.map(c => <option key={c.id} value={c.id}>{c.zh} · {c.en}</option>)}</select></label>
      <label>日期<input type="date" required value={f.expense_date} onChange={set('expense_date')} /></label>
      <label>支付方式<select value={f.payment_method} onChange={set('payment_method')}><option value="">未选择</option>{PAYMENTS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></label>
      <label>备注<textarea maxLength={500} value={f.note} onChange={set('note')} /></label>
      {err && <p role="alert" className="err">{err}</p>}
      <div className="row"><button type="button" onClick={onClose}>CANCEL</button><button className="primary" disabled={busy}>{busy ? '...' : 'SAVE EXPENSE'}</button></div>
    </form></div>
  )
}

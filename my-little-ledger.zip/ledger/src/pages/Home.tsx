import { useEffect, useState, useCallback } from 'react'
import { supabase } from '../lib/supabase'
import { CATEGORIES, yuan } from '../lib/categories'
import ExpenseForm, { Expense } from '../components/ExpenseForm'
export default function Home() {
  const [rows, setRows] = useState<Expense[]>([]); const [err, setErr] = useState(''); const [loading, setLoading] = useState(true)
  const [form, setForm] = useState<Expense | 'new' | null>(null)
  const month = new Date().toLocaleDateString('sv').slice(0, 7)
  const load = useCallback(async () => {
    const start = month + '-01'
    const { data, error } = await supabase.from('expenses').select('*').gte('expense_date', start)
      .order('expense_date', { ascending: false }).order('created_at', { ascending: false })
    if (error) setErr(error.message); else setRows((data as any[]).map(r => ({ ...r, amount: Number(r.amount) })))
    setLoading(false)
  }, [month])
  useEffect(() => { load() }, [load])
  async function del(r: Expense) {
    if (!confirm(`删除「${r.title}」？`)) return
    const { error } = await supabase.from('expenses').delete().eq('id', r.id)
    error ? setErr(error.message) : load()
  }
  const total = rows.reduce((s, r) => s + r.amount, 0)
  const sum = (id: string) => rows.filter(r => r.category === id).reduce((s, r) => s + r.amount, 0)
  return (
    <main className="page">
      <header><h1>Daily Expenses</h1><p className="sub">little things, lovely days ♡</p>
        <div className="total"><span>{month}</span><strong>{yuan(total)}</strong><span>{rows.length} 笔</span></div>
        <button className="primary" onClick={() => setForm('new')}>+ NEW EXPENSE</button>
        <button onClick={() => supabase.auth.signOut()}>退出</button></header>
      {err && <p role="alert" className="err">{err}</p>}
      <section className="grid">{CATEGORIES.map(c => (
        <div key={c.id} className="tile" style={{ background: c.color }}><c.Icon size={26} strokeWidth={1.5} />
          <b>{c.zh}</b><small>{c.en}</small><span>{yuan(sum(c.id))}</span></div>))}</section>
      <h2>Recent</h2>
      {loading ? <p>loading…</p> : rows.length === 0 ? <p className="empty">Your little story starts here ♡</p> :
        <ul className="list">{rows.slice(0, 20).map(r => <li key={r.id}><span>{r.title}<small>{r.expense_date}</small></span><b>{yuan(r.amount)}</b>
          <button onClick={() => setForm(r)}>编辑</button><button onClick={() => del(r)}>删除</button></li>)}</ul>}
      {form && <ExpenseForm initial={form === 'new' ? undefined : form} onClose={() => setForm(null)} onSaved={() => { setForm(null); load() }} />}
    </main>
  )
}

import { useState, FormEvent } from 'react'
import { Link, useNavigate } from 'react-router-dom'
import { Eye, EyeOff } from 'lucide-react'
import { supabase } from '../lib/supabase'
export default function AuthPage({ mode }: { mode: 'login' | 'signup' }) {
  const nav = useNavigate()
  const [email, setEmail] = useState(''); const [password, setPassword] = useState('')
  const [show, setShow] = useState(false); const [busy, setBusy] = useState(false)
  const [msg, setMsg] = useState<{ ok: boolean; text: string } | null>(null)
  const signup = mode === 'signup'
  async function submit(e: FormEvent) {
    e.preventDefault(); if (busy) return
    setBusy(true); setMsg(null)
    try {
      if (signup) {
        const { data, error } = await supabase.auth.signUp({ email, password, options: { emailRedirectTo: location.origin } })
        if (error) throw error
        if (data.session) nav('/')
        else if (data.user && data.user.identities?.length === 0) setMsg({ ok: false, text: '这个邮箱已经注册过啦，请直接登录。' })
        else setMsg({ ok: true, text: '验证邮件已发出，请到邮箱点击链接后再登录。' })
      } else {
        const { error } = await supabase.auth.signInWithPassword({ email, password })
        if (error) throw error
        nav('/')
      }
    } catch (err: any) { setMsg({ ok: false, text: err.message || '网络出错了，请稍后再试。' }) }
    finally { setBusy(false) }
  }
  async function forgot() {
    if (!email) return setMsg({ ok: false, text: '请先填写邮箱。' })
    const { error } = await supabase.auth.resetPasswordForEmail(email, { redirectTo: location.origin + '/settings' })
    setMsg(error ? { ok: false, text: error.message } : { ok: true, text: '重置邮件已发送，请查收。' })
  }
  return (
    <main className="auth">
      <form className="bill" onSubmit={submit}>
        <p className="no">NO. {new Date().toISOString().slice(0,10)} ♡</p>
        <h1>{signup ? 'Create your little world ♡' : 'Dear Diary,'}</h1>
        <p className="sub">A little book of my everyday life.</p>
        <label>{signup ? 'EMAIL ADDRESS' : 'ACCOUNT / EMAIL'}
          <input type="email" required autoComplete="email" value={email} onChange={e => setEmail(e.target.value)} /></label>
        <label>PASSWORD
          <span className="pw"><input type={show ? 'text' : 'password'} required minLength={8}
            autoComplete={signup ? 'new-password' : 'current-password'} value={password} onChange={e => setPassword(e.target.value)} />
            <button type="button" aria-label={show ? '隐藏密码' : '显示密码'} onClick={() => setShow(!show)}>{show ? <EyeOff size={18}/> : <Eye size={18}/>}</button></span></label>
        {msg && <p role="alert" className={msg.ok ? 'ok' : 'err'}>{msg.text}</p>}
        <button className="primary" disabled={busy}>{busy ? '...' : signup ? 'CREATE MY ACCOUNT ♡' : 'OPEN MY DIARY ♡'}</button>
        <p className="links">{signup ? <Link to="/login">已有账号？Back to login</Link> : <>
          <Link to="/signup">还没有账号？Create your account ♡</Link>
          <button type="button" className="link" onClick={forgot}>Forgot password?</button></>}</p>
        <p className="foot">Every little expense tells a story.</p>
      </form>
    </main>
  )
}

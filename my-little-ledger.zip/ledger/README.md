# My Little Ledger ♡
1. `npm install`
2. Supabase → SQL Editor → run `supabase/migrations/0001_expenses.sql`
3. Copy `.env.example` to `.env`, fill URL + anon/publishable key
4. Auth → URL Configuration: add your site URL + `http://localhost:5173`
5. `npm run dev`
Private-only mode (plan A): Supabase → Auth → Providers → Email → disable "Allow new users to sign up", then create your user in Auth → Users.
RLS: all four policies scope rows to `auth.uid()`; `user_id` defaults to `auth.uid()` so the client never sets it.
Status: NOT yet run or tested (no network in build sandbox). Remaining: category pages, /expenses filters, statistics, settings, CSV export, custom hanger/coat icons, Tailwind/Zod.

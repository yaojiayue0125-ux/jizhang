create table public.expenses (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null default auth.uid() references auth.users(id) on delete cascade,
  title text not null check (char_length(title) between 1 and 100),
  amount numeric(12,2) not null check (amount > 0),
  category text not null check (category in ('food','drinks','treats','daily_goods','fashion','beauty','transport','entertainment')),
  expense_date date not null default current_date,
  payment_method text check (payment_method in ('wechat','alipay','card','cash','other')),
  note text check (char_length(note) <= 500),
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
create index expenses_user_date_idx on public.expenses (user_id, expense_date desc);
create index expenses_user_cat_idx on public.expenses (user_id, category);

create function public.touch_updated_at() returns trigger language plpgsql as $$
begin new.updated_at = now(); return new; end $$;
create trigger expenses_touch before update on public.expenses
for each row execute function public.touch_updated_at();

alter table public.expenses enable row level security;
create policy "select own" on public.expenses for select to authenticated using (user_id = auth.uid());
create policy "insert own" on public.expenses for insert to authenticated with check (user_id = auth.uid());
create policy "update own" on public.expenses for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());
create policy "delete own" on public.expenses for delete to authenticated using (user_id = auth.uid());
